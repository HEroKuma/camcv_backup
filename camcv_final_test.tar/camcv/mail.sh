#!/bin/bash
scrot "suspicious.png"
echo "This Person Is Specting Around Your House Please Be Aware!!!" | mail -A suspicious.png -s "Remind" ghostunt893@gmail.com
