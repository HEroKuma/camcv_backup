Local Binary Patterns Histograms
--------------------------------


