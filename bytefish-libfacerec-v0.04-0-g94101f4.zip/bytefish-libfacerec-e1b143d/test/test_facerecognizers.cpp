
#include "opencv2/opencv.hpp"
#include "opencv2/ts/ts.hpp"

// some helper methods for testing
#include "test_funs.hpp"
#include "helper.hpp"

using namespace cv;
using namespace std;


// What to use: Image database? Synthetic datasets?

//------------------------------------------------------------------------------
// cv::Eigenfaces
//------------------------------------------------------------------------------
TEST(TestEigenfaces, train) {
    // TODO
    ASSERT_TRUE(false);
}

//------------------------------------------------------------------------------
// cv::Fisherfaces
//------------------------------------------------------------------------------
TEST(TestFisherfaces, train) {
    // TODO
    ASSERT_TRUE(false);
}

//------------------------------------------------------------------------------
// cv::LBPH
//------------------------------------------------------------------------------
TEST(TestLBPH, train) {
    // TODO
    ASSERT_TRUE(false);
}
