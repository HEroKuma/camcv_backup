
#include "opencv2/opencv.hpp"
#include "opencv2/ts/ts.hpp"

// some helper methods for testing
#include "test_funs.hpp"
#include "helper.hpp"

using namespace cv;
using namespace std;


//------------------------------------------------------------------------------
// subspace::project
//------------------------------------------------------------------------------
TEST(TestSubspace, subspaceProject_EmptyMean) {
    // TODO
    ASSERT_TRUE(false);
}

TEST(TestSubspace, subspaceProject_CorrectShapes) {
    // TODO
    ASSERT_TRUE(false);
}

TEST(TestSubspace, subspaceProject_WrongShapes) {
    // TODO
    ASSERT_TRUE(false);
}

TEST(TestSubspace, subspaceProject_DifferentTypes) {
    // TODO
    ASSERT_TRUE(false);
}

//------------------------------------------------------------------------------
// subspace::reconstruct
//------------------------------------------------------------------------------

TEST(TestSubspace, subspaceReconstruct_EmptyMean) {
    // TODO
    ASSERT_TRUE(false);
}

TEST(TestSubspace, subspaceReconstruct_CorrectShapes) {
    // TODO
    ASSERT_TRUE(false);
}

TEST(TestSubspace, subspaceReconstruct_WrongShapes) {
    // TODO
    ASSERT_TRUE(false);
}

TEST(TestSubspace, subspaceReconstruct_DifferentTypes) {
    // TODO
    ASSERT_TRUE(false);
}
